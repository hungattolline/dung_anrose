===== Sirpi Pro =====

Sirpi Pro plugin adds advanced features for Sirpi theme.


== Changelog ==

= 1.0.3 =

    * Fixed: Depricated and warning Errors

= 1.0.2 =

    * Fixed: Minor bugs

= 1.0.1 =

    * Demo content added in external space
    * RTL demo content added in external space

= 1.0.0 =

    * First release!