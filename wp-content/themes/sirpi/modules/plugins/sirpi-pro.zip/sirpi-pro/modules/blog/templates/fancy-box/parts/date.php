<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<!-- Entry Date -->
<div class="entry-date">
	<?php echo get_the_date ( get_option('date_format') ); ?>
</div><!-- Entry Date -->