<?php get_header(); ?>
<?php sirpi_template_part( 'post', 'templates/post' ); ?>
<?php get_footer(); ?>