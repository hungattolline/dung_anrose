<header id="header">
    <?php echo apply_filters( 'sirpi_header_get_template_part', sirpi_get_template_part( 'header', 'templates/header-content' ) ); ?>
</header>