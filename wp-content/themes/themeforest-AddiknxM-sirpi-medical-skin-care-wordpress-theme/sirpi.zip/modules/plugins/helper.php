<?php

if ( is_admin() ) {
	require_once SIRPI_MODULE_DIR . '/plugins/class-tgm-plugin-activation.php';
	require_once SIRPI_MODULE_DIR . '/plugins/tgm-plugin-activation.php';
}