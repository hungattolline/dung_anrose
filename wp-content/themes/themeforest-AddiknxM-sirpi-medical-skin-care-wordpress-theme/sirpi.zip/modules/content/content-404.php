<?php
echo apply_filters( 'sirpi_404_get_template_part', sirpi_get_template_part( '404', 'templates/404', '', sirpi_404_page_params() ) );
?>