<?php
echo apply_filters( 'sirpi_breadcrumb_get_template_part', sirpi_get_template_part( 'breadcrumb', 'templates/title-content', '',sirpi_breadcrumb_params() ), sirpi_get_page_id() ); ?>