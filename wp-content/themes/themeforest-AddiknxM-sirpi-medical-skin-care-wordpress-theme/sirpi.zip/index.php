<?php get_header(); ?>
<?php sirpi_template_part( 'blog', 'templates/post' ); ?>
<?php get_footer(); ?>