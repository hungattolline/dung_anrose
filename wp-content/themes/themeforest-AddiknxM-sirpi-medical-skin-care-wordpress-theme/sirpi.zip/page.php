<?php get_header(); ?>
<?php sirpi_template_part( 'content', 'content', 'page' ); ?>
<?php get_footer(); ?>